import h5py
import scanpy as sc
import pandas as pd
import numpy as np
import cosg
import importlib
import matplotlib

#matplotlib.use("TkAgg")

from preprocessingdata import preprocessing
import matplotlib.pyplot as plt
from collections import Counter



sc.settings.verbosity = 3
sc.logging.print_header()
sc.settings.set_figure_params(dpi=300, facecolor='white')


file_path = "muraro_logcounts.csv"
data = pd.read_csv(file_path, index_col=0,header=0, sep=" ").T
print(data.shape)
data1 = data ###备份
colnames = data.columns

colnames = np.array(colnames)

for i in range(len(colnames)):
      colnames[i]=colnames[i].split('__')[0]

colnames = colnames.tolist()
data.columns = colnames
adata = preprocessing(data)
adata = sc.AnnData(data)








label = pd.read_csv('muraro_predlabel_useinpaper.csv',header= None,encoding="unicode_escape")[0]
label = list(label)
label = [str(x) for x in label]
label = pd.Categorical(label)
adata.obs['Group'] = label

############################


sc.pp.neighbors(adata, n_neighbors=15)
sc.tl.umap(adata)


cosg.cosg(adata, key_added='cosg', groupby='Group')
sc.pl.rank_genes_groups(adata, n_genes=20, key='cosg')###n_genes这个参数用来设定想要找到的marker的数目
####增加如下两行
marker_gene = np.array(adata.uns['cosg']['names'].tolist())   #### 得到找到的marker_gene
np.savetxt(r'result\markergene_of_pred_split.txt',marker_gene,fmt="%s")


###########
sc.tl.dendrogram(adata,groupby='Group',use_rep='X_umap')
sc.pl.rank_genes_groups_dotplot(adata,groupby='Group',
                                cmap='Spectral_r',
                                 standard_scale='var',
                                n_genes=3, key='cosg', figsize=(16,10))
sc.pl.rank_genes_groups_stacked_violin(adata,groupby='Group',
                                cmap='Spectral_r',
                                 standard_scale='var',
                                n_genes=3,key='cosg', figsize=(16,10))
sc.pl.rank_genes_groups_heatmap(adata,groupby='Group',
                                cmap='Spectral_r',
                                 standard_scale='var',
                                n_genes=3,key='cosg',figsize=(14,8))


